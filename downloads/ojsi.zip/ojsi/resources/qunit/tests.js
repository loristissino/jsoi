test( "hello test", function() {
  ok( 1 == "1", "Passed!" );
});
